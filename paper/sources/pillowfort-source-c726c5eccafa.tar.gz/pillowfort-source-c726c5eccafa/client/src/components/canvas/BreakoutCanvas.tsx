import { useRef, useEffect, useCallback } from "react";
import { BALL_R, PADDLE_H, createBreakout, stepBreakout, breakoutResultMessage, type BreakoutSnapshot } from "../../../../src/participant/breakout";
import { send } from "../../services/ws";
import { beep } from "../../hooks/useSound";
import { agentMode, registerBreakout, notifyBreakout } from "../../agent/breakout";

const MOBILE_PADDLE_LIFT_PX = 50;
const FOCUS_BAR_GAP_PX = 16;

export function BreakoutCanvas({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bootFrameRef = useRef<number>(0);
  const stateRef = useRef<BreakoutSnapshot | null>(null);
  const animRef = useRef<number>(0);
  const keysRef = useRef<Record<string, boolean>>({});

  const sendBreakoutMessage = useCallback((text: string) => {
    send("chat", { text });
  }, []);

  const reset = useCallback(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const parent = cv.parentElement;
    if (!parent) return;
    const rect = parent.getBoundingClientRect();
    cv.width = rect.width;
    cv.height = rect.height;
    const w = cv.width, h = cv.height;
    const isMobile = window.matchMedia("(max-width: 600px)").matches;
    const paddleLift = isMobile ? MOBILE_PADDLE_LIFT_PX : 0;
    const focusBarRect = parent.querySelector(".room-focus-bar")?.getBoundingClientRect();
    const focusBarExtent = focusBarRect?.height ? Math.max(0, rect.bottom - focusBarRect.top) : 0;
    const barH = Math.max(50 + paddleLift, focusBarExtent + PADDLE_H + FOCUS_BAR_GAP_PX);
    stateRef.current = createBreakout(w, h, barH);
  }, []);

  const stopGameLoop = useCallback(() => {
    if (bootFrameRef.current) {
      cancelAnimationFrame(bootFrameRef.current);
      bootFrameRef.current = 0;
    }
    if (animRef.current) {
      cancelAnimationFrame(animRef.current);
      animRef.current = 0;
    }
    if (stateRef.current) stateRef.current.running = false;
  }, []);

  useEffect(() => {
    if (!active) {
      stopGameLoop();
      return;
    }

    const cv = canvasRef.current;
    if (!cv) return;
    const ctx = cv.getContext("2d")!;
    let disposed = false;
    const agentEnabled = agentMode();
    let lastAgentFrame = 0;

    bootFrameRef.current = requestAnimationFrame(() => {
      bootFrameRef.current = 0;
      if (disposed) return;
      // Returning from chat creates a fresh canvas element. Reinitialize against
      // its actual dimensions instead of reusing coordinates from the old canvas.
      reset();
      if (!stateRef.current) return;
      stateRef.current.running = true;

      function loop() {
        const s = stateRef.current;
        if (disposed || !s || !s.running) return;
        const w = cv!.width, h = cv!.height;

        stepBreakout(s, effect => {
          if (effect === "paddle") beep(520, 0.05, 0, 0.04);
          if (effect === "brick") beep(880, 0.03, 0, 0.03);
          if (effect === "won") {
            beep(523, 0.1, 0, 0.06); beep(659, 0.1, 0.1, 0.06);
            beep(784, 0.1, 0.2, 0.06); beep(1047, 0.3, 0.3, 0.08);
          }
          if (effect === "lost") { beep(220, 0.3, 0, 0.08); beep(165, 0.4, 0.2, 0.08); }
          if (effect === "won" || effect === "lost") sendBreakoutMessage(breakoutResultMessage(s));
        });

        // Draw
        ctx.clearRect(0, 0, w, h);
        ctx.fillStyle = "rgba(0,0,0,0.85)";
        ctx.fillRect(0, 0, w, h);

        ctx.fillStyle = "#fff";
        for (let i = 0; i < 40; i++) {
          const sx = (i * 137.5) % w, sy = (i * 97.3) % h;
          ctx.globalAlpha = 0.3 + (i % 5) * 0.1;
          ctx.fillRect(sx, sy, 1.5, 1.5);
        }
        ctx.globalAlpha = 1;

        s.bricks.forEach((b) => {
          if (!b.alive) return;
          ctx.fillStyle = b.color;
          ctx.beginPath();
          ctx.roundRect(b.x, b.y, b.w, b.h, 3);
          ctx.fill();
        });

        ctx.fillStyle = "#ECE9D8";
        ctx.beginPath();
        ctx.roundRect(s.paddle.x, s.paddle.y, s.paddle.w, s.paddle.h, 4);
        ctx.fill();
        ctx.strokeStyle = "#ACA899";
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.fillStyle = "#FFD700";
        ctx.beginPath();
        ctx.arc(s.ball.x, s.ball.y, BALL_R, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#fff";
        ctx.font = "11px Tahoma, sans-serif";
        ctx.textAlign = "left";
        ctx.fillText("❤".repeat(s.lives), 8, 20);
        ctx.textAlign = "right";
        ctx.fillText("Score: " + s.score, w - 8, 20);

        if (s.won) {
          ctx.fillStyle = "#FFD700";
          ctx.font = "bold 24px Tahoma, sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("You win! Score: " + s.score, w / 2, h / 2);
          ctx.font = "12px Tahoma, sans-serif";
          ctx.fillStyle = "#fff";
          ctx.fillText("Click to play again", w / 2, h / 2 + 24);
        }

        if (s.lost) {
          ctx.fillStyle = "#FF6B6B";
          ctx.font = "bold 24px Tahoma, sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("Game Over — Score: " + s.score, w / 2, h / 2);
          ctx.font = "12px Tahoma, sans-serif";
          ctx.fillStyle = "#fff";
          ctx.fillText("Click to try again", w / 2, h / 2 + 24);
        }

        if (agentEnabled && performance.now() - lastAgentFrame >= 100) {
          lastAgentFrame = performance.now();
          notifyBreakout();
        }
        animRef.current = requestAnimationFrame(loop);
      }

      loop();
    });

    // Input handlers
    const cv2 = cv;
    const resizeObserver = new ResizeObserver(() => reset());
    if (cv.parentElement) resizeObserver.observe(cv.parentElement);
    const setPaddleFromClientX = (clientX: number) => {
      if (!stateRef.current?.running) return;
      const rect = cv2.getBoundingClientRect();
      stateRef.current.paddle.x = Math.max(
        0,
        Math.min(cv2.width - stateRef.current.paddle.w, (clientX - rect.left) * (cv2.width / rect.width) - stateRef.current.paddle.w / 2)
      );
    };
    const onMouse = (e: MouseEvent) => {
      setPaddleFromClientX(e.clientX);
    };
    const onTouchStart = (e: TouchEvent) => {
      if (!stateRef.current) return;
      e.preventDefault();
      if (stateRef.current.won || stateRef.current.lost) {
        reset();
      }
      if (e.touches.length > 0) setPaddleFromClientX(e.touches[0].clientX);
    };
    const onTouchMove = (e: TouchEvent) => {
      if (!stateRef.current?.running) return;
      e.preventDefault();
      if (e.touches.length > 0) setPaddleFromClientX(e.touches[0].clientX);
    };
    const onClick = () => {
      if (stateRef.current?.won || stateRef.current?.lost) reset();
    };
    const onKeyDown = (e: KeyboardEvent) => { keysRef.current[e.key] = true; };
    const onKeyUp = (e: KeyboardEvent) => { keysRef.current[e.key] = false; };
    const unregisterAgent = agentEnabled ? registerBreakout({
      move: (x) => {
        const rect = cv.getBoundingClientRect();
        setPaddleFromClientX(rect.left + x * rect.width);
      },
      reset,
      snapshot: () => {
        const s = stateRef.current;
        return s ? {
          width: cv.width, height: cv.height,
          ball: { ...s.ball }, paddle: { ...s.paddle },
          bricks: s.bricks.map(brick => ({ ...brick })),
          lives: s.lives, score: s.score, won: s.won, lost: s.lost, running: s.running,
        } : null;
      },
    }) : null;

    cv.addEventListener("mousemove", onMouse);
    cv.addEventListener("touchstart", onTouchStart, { passive: false });
    cv.addEventListener("touchmove", onTouchMove, { passive: false });
    cv.addEventListener("click", onClick);
    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("keyup", onKeyUp);

    const keyInterval = setInterval(() => {
      if (!stateRef.current?.running) return;
      if (keysRef.current.ArrowLeft) stateRef.current.paddle.x = Math.max(0, stateRef.current.paddle.x - 6);
      if (keysRef.current.ArrowRight) stateRef.current.paddle.x = Math.min(cv.width - stateRef.current.paddle.w, stateRef.current.paddle.x + 6);
    }, 16);

    return () => {
      disposed = true;
      stopGameLoop();
      unregisterAgent?.();
      clearInterval(keyInterval);
      resizeObserver.disconnect();
      cv.removeEventListener("mousemove", onMouse);
      cv.removeEventListener("touchstart", onTouchStart);
      cv.removeEventListener("touchmove", onTouchMove);
      cv.removeEventListener("click", onClick);
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("keyup", onKeyUp);
    };
  }, [active, reset, sendBreakoutMessage, stopGameLoop]);

  if (!active) return null;

  return <canvas id="breakout-canvas" ref={canvasRef} className="breakout-canvas" />;
}
