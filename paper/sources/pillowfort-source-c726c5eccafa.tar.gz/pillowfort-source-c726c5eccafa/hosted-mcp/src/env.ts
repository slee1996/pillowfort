import type { OAuthHelpers } from '@cloudflare/workers-oauth-provider';
import type { HostedMcpSession } from './session';
import type { AccessKeyStore } from './auth';
import type { ParticipantQuota } from './quota';
import type { TelemetryEnv } from '../../src/telemetry';

export interface Env extends TelemetryEnv {
  /** Principal-bound application actors; the binding name is stable across deployments. */
  MCP_SESSIONS: DurableObjectNamespace<HostedMcpSession>;
  MCP_ACCESS_KEYS: DurableObjectNamespace<AccessKeyStore>;
  MCP_QUOTAS: DurableObjectNamespace<ParticipantQuota>;
  OAUTH_KV: KVNamespace;
  OAUTH_PROVIDER: OAuthHelpers;
  ADMIN_TOKEN: string;
  CONSENT_SECRET: string;
  PUBLIC_MCP_URL: string;
  APP_URL: string;
  ALLOWED_ORIGINS: string;
  MAX_ACTIVE_SESSIONS: string;
  MAX_DAILY_SESSION_MINUTES: string;
  MAX_SESSION_SECONDS: string;
  IDLE_TIMEOUT_SECONDS: string;
}

export interface AuthenticatedProps {
  principalId: string;
}

export type LeaseResult =
  | { ok: true; expiresAt: number }
  | { ok: false; code: string; retryAfter: number };
