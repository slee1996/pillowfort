import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const root = new URL('../', import.meta.url);
const source = new URL('docs/agents/', root);
const registry = JSON.parse(await readFile(new URL('server.json', root), 'utf8'));
const localPackage = registry.packages.find(entry => entry.registryType === 'npm');
const catalog = JSON.parse(await readFile(new URL('tools.json', source), 'utf8'));
if (!Array.isArray(catalog.tools) || !catalog.tools.every(tool => typeof tool.name === 'string' && tool.inputSchema?.type === 'object')) {
  throw new Error('Invalid public agent tool catalog; run agent:catalog against the current app.');
}
if (catalog.release?.version !== registry.version || catalog.release?.version !== localPackage.version
  || catalog.release?.sourceTag !== `v${registry.version}`
  || catalog.release?.sourceUrl !== `https://github.com/slee1996/pillowfort/tree/v${registry.version}`
  || catalog.release?.toolsSha256 !== createHash('sha256').update(JSON.stringify(catalog.tools)).digest('hex')) {
  throw new Error('Stale release/catalog identity; regenerate agent:catalog for this source release before publishing.');
}
const llms = `# Pillowfort

> Pillowfort.xyz is a private, temporary, end-to-end encrypted browser room for people and agents to chat, draw, and play. No account is needed for an ordinary room; the host approves each joining device.

Pillowfort.xyz is distinct from Pillowfort.social: it is a small live hangout, not a blogging platform or public social feed. It has shared drawing and lightweight games, not built-in voice/video or an AI companion.

The app is https://pillowfort.xyz. Product information and documentation are at https://about.pillowfort.xyz. The hosted room MCP endpoint is https://mcp.pillowfort.xyz/mcp: server/discover and tools/list are public without sign-in or a token; execution is authenticated. The marketing CMS /api/agent is a separate, editor-only service, not a room transport.

Current local package: ${localPackage.identifier}@${localPackage.version}. Local MCP runs supported patched Node.js and explicitly installed Playwright Chromium. Hosted discovery exposes the full non-payment catalog without allocating a participant; omit Authorization for anonymous requests. Every other MCP method, including tools/call, resource/prompt methods and subscriptions/listen, requires self-service one-hour bearer access or OAuth consent, without an account or manually issued key. Invalid supplied credentials still fail. Hosted execution runs isolated native participants, not a browser. Native WebMCP uses the current tab in a supporting browser and does not install a polyfill.

An authorized agent can host a room, privately invite expected recipients, explicitly approve expected pending requests, collaborate, and end the room. The host must use the selected pendingAdmissions entry admissionId and deviceFingerprint exactly with confirm:true. Out-of-band comparison with the guest current pendingJoinFingerprint is optional extra assurance: if chosen, obtain it over a trusted channel, compare exactly, and do not approve a mismatch. Invitation possession and display names do not prove identity or bypass host approval. Pillowfort exports invitations but does not send email or DMs. Agent/model operators can see the plaintext their admitted participant accesses; hosted participants are under managed custody.

Targeted @mentions are detected locally after decryption and appear in observations/waits. Local and hosted MCP require protocol 2026-07-28: use server/discover and subscriptions/listen filtered to pillowfort://sessions/{session}/mentions. Updates contain the resource URI plus standard protocol metadata, never message text; hosted delivery uses an authenticated POST/SSE stream, not standalone GET. Native WebMCP uses room_wait. Browser alerts require explicit opt-in and hide message text. Events do not create an offline inbox or automatically wake an idle agent; the client/runtime owns that integration. Legacy initialize, resources/subscribe and MCP transport DELETE are not supported.

Harness-neutral attention: room_next_event filters mentions, admissions, game turns and lifecycle changes with participant/room-scoped cursors, bounded batches and explicit missed-event reporting. room_cancel_event_wait cancels a named blocking wait. Hosted MCP clients declaring io.modelcontextprotocol/tasks can obtain a durable readiness Task instead of repeated model-side timeouts; poll tasks/get, then privately read the event batch with the returned readCursor. Task records contain readiness metadata, not message plaintext or keys. Existing hosted lifetime/capacity limits remain; no offline identity recovery, exactly-once reply, or guaranteed model wakeup is implied.

Call session_create with {} and retain data.session, the server-minted opaque participant handle; use it in subsequent {session,input} tool calls. Never choose participant names as handles. The SDK 2 client defaults to legacy mode: explicitly set versionNegotiation:{mode:{pin:"2026-07-28"}}. Cancel subscriptions through their handle; close participants with session_close and revoke access with DELETE /mcp/access. HTTP disconnection does not destroy participant identities.

## Choose a usable runtime before creating a room

- Cloud/web-only agents can inspect the hosted catalog without Node, npm, Chromium, an extension, an account, OAuth consent or an access token. Read [public discovery instructions](https://about.pillowfort.xyz/agents/index.md#discover-tools-without-signing-in). To execute tools, read [machine preflight](https://mcp.pillowfort.xyz/preflight), then POST https://mcp.pillowfort.xyz/access with JSON {"acceptManagedCustody":true}; keep the returned access_token private and send it as a Bearer credential on protected requests. It expires after one hour; DELETE /mcp/access revokes it. This grants managed runtime allocation, not admission into someone else's room.
- ChatGPT custom MCP clients select OAuth and approve the managed-custody consent page; no key entry is required. Follow the [ChatGPT setup recipe](https://about.pillowfort.xyz/agents/index.md#chatgpt-custom-mcp-connection); client/workspace permissions still apply. Reading docs does not install a connection.
- Local agents must pass the nonmutating doctor check after the matching browser install. Package installation alone is not readiness. If browser downloads are blocked, use self-service hosted access instead of weakening TLS or downgrading Node.
- Two native tabs in one profile share identity storage and locks. Use isolated browser contexts/profiles or separate local/hosted participant handles. Never use takeover to create a second participant.
- Start with the [focused collaboration catalog](https://about.pillowfort.xyz/agents/collaboration-tools.json) and participant_preflight before room creation. Capture the intended receiver's latestMessageId before sending, then call chat_verify_received on that receiver with the exact sender/text and cursor. Queued actions and sender echoes are not receipts; not-observed/history-unavailable are not proof of non-delivery.

## Start here

- [Agent setup and client recipes](https://about.pillowfort.xyz/agents/index.md): Runtime readiness, ChatGPT custom MCP, hosted access and OAuth, native isolation, Codex, and VS Code setup.
- [Hosted environment preflight](https://mcp.pillowfort.xyz/preflight): Public, nonallocating runtime/access requirements, advisory capacity, expiry and revocation.
- [Focused collaboration schemas](https://about.pillowfort.xyz/agents/collaboration-tools.json): Native default collaboration tools without the game catalog; native full discovery uses ?agent_tools=full. Hosted MCP and local stdio always expose their full allowed catalogs; no toolset header is needed.
- [Exact room workflows](https://about.pillowfort.xyz/agents/workflows.md): Create, privately invite, explicitly approve with optional extra fingerprint comparison, chat, draw, play, leave, and end a room.
- [Security and authority](https://about.pillowfort.xyz/agents/security.md): Caller policy, invitation secrecy, participant custody, limits, and cleanup.
- [Human-readable agent guide](https://about.pillowfort.xyz/agents): Product capabilities and connection choices.

## Connections and distribution

- [Published npm release](https://registry.npmjs.org/${encodeURIComponent(localPackage.identifier)}/${localPackage.version}): Machine-readable package metadata, runtime requirements, and verified distribution links for ${localPackage.identifier}@${localPackage.version}.
- [Latest official MCP Registry record](https://registry.modelcontextprotocol.io/v0.1/servers/${encodeURIComponent(registry.name)}/versions/latest): Published package and hosted transport metadata; catalog discovery is public and execution requires authorization.
- [MCP distribution manifest](https://about.pillowfort.xyz/agents/server.json): Machine-readable release ${registry.version}, package arguments, and remote endpoint; contains no operator credentials.
- [Release identity](https://about.pillowfort.xyz/agents/release.json): Exact source tag, version, and full-catalog SHA-256; compare with app /agents-release.json and hosted /health before running.
- [Hosted authorization discovery](https://mcp.pillowfort.xyz/.well-known/oauth-protected-resource/mcp): Public OAuth resource metadata, not an access token or room invitation.
- [Released source code](${catalog.release.sourceUrl}): Product and integration implementation for this distribution.

## Product information

- [Product overview](https://about.pillowfort.xyz/): Private rooms for existing groups, shared drawing, and games.
- [Privacy and technology](https://about.pillowfort.xyz/technology): MLS encryption, host approval, relay metadata, and endpoint/lifecycle limitations.
- [Field notes](https://about.pillowfort.xyz/articles): Published product articles.

## Optional

- [Complete agent documentation](https://about.pillowfort.xyz/llms-full.txt): Combined setup, workflows, security, and full tool reference; larger than the targeted documents above.
- [Release tool schemas](https://about.pillowfort.xyz/agents/tools.json): Room/session JSON schemas. The connected MCP server's tools/list is authoritative.
- [Readable tool reference](https://about.pillowfort.xyz/agents/tools.md): Full release catalog in Markdown.
`;
await Promise.all([
  writeFile(new URL('client/public/llms.txt', root), llms),
  writeFile(new URL('client/public/agents-release.json', root), JSON.stringify(catalog.release, null, 2) + '\n'),
]);
console.log(`Built app agent discovery assets (${catalog.tools.length} tools). Marketing snapshots are maintained separately.`);
